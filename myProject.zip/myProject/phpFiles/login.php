<?php

    $db = mysqli_connect('localhost' , 'admin' , '', 'test');

    $email = $_POST['email'];
    $password =$_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";

   $result = mysqli_query($db, $sql);
   if($result->num_rows === 1){
       header("Location: http://localhost/myProject/books.html");
   }else{
       header("Location: http://localhost/myProject/login.html");

       exit();
   }