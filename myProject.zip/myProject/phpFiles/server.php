<?php

    $db = mysqli_connect('localhost' , 'admin' , '', 'test');

        $email = $_POST['email'];
        $password =$_POST['psw'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $telephone = $_POST['usrtel'];
        $gender = $_POST['gender'];
        $birthday = $_POST['bday'];
        $city = $_POST['city'];

        $sql = "INSERT INTO users (email, password, firstName, lastName, telephone, gender, birthday, city)
                 VALUES ('$email','$password', '$firstName','$lastName','$telephone','$gender','$birthday', '$city')";

        mysqli_query($db, $sql);

        header("Location: http://localhost/myProject/login.html");



