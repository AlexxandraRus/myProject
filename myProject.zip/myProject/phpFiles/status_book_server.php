<?php

    $db = mysqli_connect('localhost' , 'admin' , '', 'test');

    $bookstatus = $_POST['bookstatus'];
    $id = $_POST['id'];



   $sql = "INSERT INTO bookstatus(bookStatus, email, id_myBooks)
        VALUE ('$bookstatus', 'rus_alexxandra@gmail.com' '$id')";

    mysqli_query($db, $sql);