<?php

$db = mysqli_connect('localhost' , 'admin' , '', 'test');

$author = $_POST['author'];
$bookName =$_POST['bookname'];



$sql = "SELECT * FROM myBooks WHERE author='$author' AND bookName='$bookName'";

$result = mysqli_query($db, $sql);


if($result->num_rows === 1){
    echo "Cartea deja exista!";
}else {
    $sql = "INSERT INTO mybooks (author, bookName)
                 VALUES ('$author','$bookName')";

    mysqli_query($db, $sql);

    $sql = "SELECT id FROM myBooks WHERE author='$author' AND bookName='$bookName'";

    $result = mysqli_query($db, $sql);

    $rows = $result->fetch_array();
    $id = $rows['id'];

    header("Location: http://localhost/myProject/status_book.phtml?id=$id");

 }