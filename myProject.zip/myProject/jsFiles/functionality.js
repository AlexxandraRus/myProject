function validatePassword() {
    var pass = document.getElementById('psw').value;
    var pass2 = document.getElementById('psw-repeat').value;
    if(pass!=pass2){
           document.getElementById('psw-repeat').value='';
           document.getElementById('psw-repeat').focus() ;
    }

}
function phonenumber()
{
    var tel =document.getElementById('tel').value;
    var phonenr = '/^\d{10}$/';

    if(tel.match(phonenr))
    {
        return true;
    }
    else
    {
        alert("Stupid");
        return false;
    }

}